# Production Checklist

## Infrastructure
- [ ] Managed PostgreSQL
- [ ] HTTPS + domain
- [ ] Secret manager
- [ ] Object storage + CDN
- [ ] API deployment
- [ ] Background worker/queue
- [ ] Monitoring + error tracking
- [ ] Database backups

## Security
- [ ] Replace demo JWT secret
- [ ] Secure HTTP-only session or OIDC
- [ ] Password hashing with Argon2id/bcrypt
- [ ] Rate limiting
- [ ] Input validation
- [ ] Tenant isolation on every query
- [ ] Audit logging
- [ ] CORS allowlist
- [ ] File type/size validation
- [ ] Signed upload/download URLs

## Integrations
- [ ] AI provider
- [ ] WhatsApp Business API
- [ ] Meta Ads API
- [ ] TikTok Ads API
- [ ] Analytics events

## Business
- [ ] Subscription/billing
- [ ] Workspace onboarding
- [ ] Agent invitation
- [ ] Usage limits
- [ ] Terms/privacy
