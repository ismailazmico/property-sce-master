# PROPERTY SCE MASTER V4.0

Browser / Mobile Web
        |
      HTTPS
        |
      API Gateway
        |
  ┌─────┼──────────┬───────────┐
 Auth  Property   CRM/AI     Campaign
  |       |          |           |
 RBAC  PostgreSQL  AI Worker   Ads APIs
             |
        Object Storage/CDN
             |
         Creative Renderer

Core principle: property facts are the source of truth. AI produces structured drafts, while final publishing remains a separate controlled step.
