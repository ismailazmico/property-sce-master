import express from "express";
import cors from "cors";
import helmet from "helmet";
import crypto from "node:crypto";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { z } from "zod";
import pg from "pg";

const app=express();
app.use(helmet());
app.use(cors({origin:process.env.WEB_ORIGIN||true,credentials:true}));
app.use(express.json({limit:"2mb"}));

const PORT=process.env.PORT||4000;
const JWT_SECRET=process.env.JWT_SECRET||"CHANGE_THIS_IN_PRODUCTION";
const pool=process.env.DATABASE_URL ? new pg.Pool({connectionString:process.env.DATABASE_URL}) : null;

const demo={users:[{id:"demo-admin",email:"admin@sce.local",role:"admin",workspace_id:"demo-workspace"}],
properties:[],media:[],leads:[],aiJobs:[],renders:[],campaigns:[]};

function auth(req,res,next){
  const h=req.headers.authorization||"";
  if(!h.startsWith("Bearer ")) return res.status(401).json({error:"Unauthorized"});
  try{req.user=jwt.verify(h.slice(7),JWT_SECRET);next()}catch{res.status(401).json({error:"Invalid token"})}
}
function role(...roles){return (req,res,next)=>roles.includes(req.user?.role)?next():res.status(403).json({error:"Forbidden"})}
const id=()=>crypto.randomUUID();

app.get("/health",async(_,res)=>res.json({ok:true,version:"4.0",db:!!pool}));

app.post("/api/auth/login",async(req,res)=>{
  const {email,password}=req.body||{};
  if(email==="admin@sce.local"&&password==="demo123"){
    const token=jwt.sign({sub:"demo-admin",workspace_id:"demo-workspace",role:"admin",email},JWT_SECRET,{expiresIn:"8h"});
    return res.json({token,user:{id:"demo-admin",email,role:"admin",workspace_id:"demo-workspace"}});
  }
  res.status(401).json({error:"Invalid credentials"});
});

const propertySchema=z.object({
  name:z.string().min(1),location:z.string().optional(),price:z.number().nullable().optional(),
  tenure:z.string().optional(),bedrooms:z.number().int().nonnegative().optional(),
  bathrooms:z.number().int().nonnegative().optional(),built_up:z.string().optional(),
  lot_type:z.string().optional(),verified_usps:z.array(z.string()).default([])
});

app.get("/api/properties",auth,async(req,res)=>{
  if(pool){
    const r=await pool.query("select * from properties where workspace_id=$1 order by created_at desc",[req.user.workspace_id]);
    return res.json(r.rows);
  }
  res.json(demo.properties.filter(x=>x.workspace_id===req.user.workspace_id));
});
app.post("/api/properties",auth,async(req,res)=>{
  const parsed=propertySchema.safeParse(req.body); if(!parsed.success)return res.status(400).json({error:parsed.error.flatten()});
  const p={id:id(),workspace_id:req.user.workspace_id,owner_id:req.user.sub,...parsed.data};
  if(pool){
    const r=await pool.query(`insert into properties(id,workspace_id,owner_id,name,location,price,tenure,bedrooms,bathrooms,built_up,lot_type,verified_usps)
      values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) returning *`,
      [p.id,p.workspace_id,p.owner_id,p.name,p.location,p.price,p.tenure,p.bedrooms,p.bathrooms,p.built_up,p.lot_type,JSON.stringify(p.verified_usps)]);
    return res.status(201).json(r.rows[0]);
  }
  demo.properties.unshift(p);res.status(201).json(p);
});

app.post("/api/media/presign",auth,async(req,res)=>{
  const filename=String(req.body?.filename||"file");
  const key=`${req.user.workspace_id}/${id()}-${filename.replace(/[^a-zA-Z0-9._-]/g,"_")}`;
  res.json({storageKey:key,uploadUrl:`/api/media/mock-upload?key=${encodeURIComponent(key)}`,expiresIn:900});
});
app.post("/api/media/complete",auth,async(req,res)=>{
  const m={id:id(),workspace_id:req.user.workspace_id,...req.body};
  if(pool){
    const r=await pool.query(`insert into media(id,workspace_id,property_id,storage_key,original_name,mime_type,size_bytes,tag)
      values($1,$2,$3,$4,$5,$6,$7,$8) returning *`,
      [m.id,m.workspace_id,m.property_id,m.storage_key,m.original_name,m.mime_type,m.size_bytes,m.tag]);
    return res.status(201).json(r.rows[0]);
  }
  demo.media.unshift(m);res.status(201).json(m);
});

app.get("/api/leads",auth,async(req,res)=>{
  if(pool){const r=await pool.query("select * from leads where workspace_id=$1 order by created_at desc",[req.user.workspace_id]);return res.json(r.rows)}
  res.json(demo.leads.filter(x=>x.workspace_id===req.user.workspace_id));
});
app.post("/api/leads",auth,async(req,res)=>{
  const l={id:id(),workspace_id:req.user.workspace_id,owner_id:req.user.sub,stage:"new",...req.body};
  if(pool){const r=await pool.query(`insert into leads(id,workspace_id,property_id,owner_id,name,phone,email,stage,source,notes)
  values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) returning *`,
  [l.id,l.workspace_id,l.property_id,l.owner_id,l.name,l.phone,l.email,l.stage,l.source,l.notes]);return res.status(201).json(r.rows[0])}
  demo.leads.unshift(l);res.status(201).json(l);
});
app.patch("/api/leads/:id",auth,async(req,res)=>{
  if(pool){const r=await pool.query("update leads set stage=coalesce($1,stage),notes=coalesce($2,notes),updated_at=now() where id=$3 and workspace_id=$4 returning *",[req.body.stage,req.body.notes,req.params.id,req.user.workspace_id]);return r.rowCount?res.json(r.rows[0]):res.sendStatus(404)}
  const l=demo.leads.find(x=>x.id===req.params.id&&x.workspace_id===req.user.workspace_id);if(!l)return res.sendStatus(404);Object.assign(l,req.body);res.json(l);
});

app.post("/api/ai/jobs",auth,async(req,res)=>{
  const {property,funnel="Cold",audience="Pembeli rumah",angle="Property Showcase"}=req.body||{};
  if(!property?.name)return res.status(400).json({error:"property required"});
  const headline=funnel==="Cold"?`Kenali ${property.name} di ${property.location||""}`:funnel==="Warm"?`Kenapa property ini patut masuk shortlist?`:`Jom semak viewing ${property.name}`;
  const output={headline,primary_text:`${property.bedrooms||"-"} bilik • ${property.bathrooms||"-"} bilik air • ${property.built_up||"-"}.\n${(property.verified_usps||[]).join(", ")}.\nHarga: ${property.price??"Hubungi untuk harga"}.`,cta:"WhatsApp untuk detail & viewing",funnel,audience,angle};
  const job={id:id(),workspace_id:req.user.workspace_id,owner_id:req.user.sub,property_id:property.id||null,status:"completed",output};
  if(pool){const r=await pool.query(`insert into ai_jobs(id,workspace_id,owner_id,property_id,funnel_stage,request,response,provider,status)
    values($1,$2,$3,$4,$5,$6,$7,$8,$9) returning *`,
    [job.id,job.workspace_id,job.owner_id,job.property_id,funnel,JSON.stringify(req.body),JSON.stringify(output),process.env.AI_PROVIDER||"demo","completed"]);return res.status(201).json(r.rows[0])}
  demo.aiJobs.unshift(job);res.status(201).json(job);
});

app.post("/api/creative/renders",auth,async(req,res)=>{
  const render={id:id(),workspace_id:req.user.workspace_id,owner_id:req.user.sub,status:"draft",...req.body};
  if(pool){const r=await pool.query(`insert into creative_renders(id,workspace_id,owner_id,property_id,format,brief,status)
    values($1,$2,$3,$4,$5,$6,$7) returning *`,
    [render.id,render.workspace_id,render.owner_id,render.property_id,render.format,JSON.stringify(render.brief||{}),"draft"]);return res.status(201).json(r.rows[0])}
  demo.renders.unshift(render);res.status(201).json(render);
});

app.listen(PORT,()=>console.log(`PROPERTY SCE MASTER API ${PORT}`));
