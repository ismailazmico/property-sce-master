# Deployment

Recommended production topology:

CDN / HTTPS
   ↓
Web App
   ↓
API
   ├── PostgreSQL
   ├── Object Storage
   ├── AI Worker
   ├── WhatsApp adapter
   └── Ads platform adapters

Use a managed PostgreSQL and managed object storage for production.

Docker Compose in this folder is intended for development/self-hosted staging, not as a claim of production hosting.
