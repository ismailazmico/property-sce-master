# PROPERTY SCE MASTER — FRONTEND LIVE

Render Static Site settings:
- Root Directory: blank
- Build Command: blank
- Publish Directory: .
- Branch: main

Upload/commit the CONTENTS of this folder to the repository root. Do not upload the ZIP itself as the site source.
